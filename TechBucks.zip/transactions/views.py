from django.shortcuts import render, get_object_or_404, redirect
from students.models import Student
from .forms import TransactionForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required

@login_required
def add_transaction(request, student_id=None):
    student = get_object_or_404(Student, student_id=student_id)

    if request.method == 'POST':
        form = TransactionForm(request.POST)
        if form.is_valid():
            is_class_transaction = form.cleaned_data.get('is_class_transaction')
            amount = form.cleaned_data.get('amount')  # Get the transaction amount
            description = form.cleaned_data.get('description')  # Get the description

            # If it's a class transaction, apply the transaction to all students in the homeroom
            if is_class_transaction:
                homeroom = student.homeroom
                students_in_class = Student.objects.filter(homeroom=homeroom)
                for class_student in students_in_class:
                    # Create a separate transaction for each student in the class
                    Transaction.objects.create(
                        student=class_student,
                        amount=amount,
                        description=f"Class Transaction: {description}",
                        performed_by=request.user  # Set the teacher/user performing the transaction
                    )
            else:
                # Apply the transaction to the individual student
                transaction = form.save(commit=False)
                transaction.student = student
                transaction.performed_by = request.user  # Set the teacher/user performing the transaction
                transaction.save()

            # Redirect to the student's profile after the transaction
            return redirect('students:student_profile', student_id=student.student_id)

    else:
        form = TransactionForm(initial={'student': student})

    return render(request, 'transactions/transaction_form.html', {
        'form': form,
        'student': student,
    })



def update_points(request, student_id):
    student = get_object_or_404(Student, student_id=student_id)
    if request.method == 'POST':
        points = int(request.POST.get('points', 0))
        description = request.POST.get('description', 'Point update')  # Get the description, default to 'Point update'

        # Create a new transaction and track who performed the action
        Transaction.objects.create(
            student=student,
            amount=points,
            description=description,
            performed_by=request.user  # Track the teacher/user who performed the transaction
        )

        return redirect('students:student_profile', student_id=student_id)
    return render(request, 'students/student_profile.html', {'student': student})


# students/admin.py

from django.contrib import admin
from .models import Student
from transactions.models import Transaction

class TransactionInline(admin.TabularInline):
    model = Transaction
    extra = 0

class StudentAdmin(admin.ModelAdmin):
    list_display = ('student_id', 'first_name', 'last_name', 'grade', 'homeroom', 'homeroom_teacher', 'total_techbucks')
    search_fields = ('student_id', 'first_name', 'last_name', 'homeroom', 'homeroom_teacher')
    inlines = [TransactionInline]

admin.site.register(Student, StudentAdmin)
